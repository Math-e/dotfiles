# NCMPCPP
> Purify theme for NCMPCPP

<p align="center">
  <img src="https://i.imgur.com/6mOmOQR.png" width="700px">
</p>

<p align="center">
  <img src="https://i.imgur.com/uy81dsh.png" width="700px">
</p>

## Installation

Due to lack of config, this is just the minimal config for ncmpcpp i'v tried to implement for Purify

If you haven't config ncmpcpp yet, just download [config file](./config) and place it in `~/.config/ncmpcpp/config`

If you already have your config file, you have to copy color configs in [config file](./config) and add them manually to your config

:warning: Note:
If the color doesn't look like in the demo, you have to install Purify for your terminal first.
Currently, Purify support some or terminal but not all, if your browser not in the list, please open an issue and let me know.

## Lisence
MIT © [Kyoz](mailto:banminkyoz@gmail.com)
