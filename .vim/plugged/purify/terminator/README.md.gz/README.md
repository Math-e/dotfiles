# Terminator
> Purify theme for Terminator

<br>
<p align="center">
  <img src="https://i.imgur.com/sptNkFN.png" width="700px">
</p>

## Installation

Copy the `config` file to `~/.config/terminator/` directory (Create if diretory doesn't exist)


Or you can just copy the Color config of Purify and paste to your current terminator's config file.

## References

If you are using zsh, please take a look at [purify/zsh](https://github.com/kyoz/purify/tree/master/zsh) to get zsh config for purify.

## Lisence
MIT © [Kyoz](mailto:banminkyoz@gmail.com)
