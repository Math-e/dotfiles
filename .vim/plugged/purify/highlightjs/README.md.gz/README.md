# Highlightjs
> Purify theme for Highlightjs

<p align="center">
  <img src="https://i.imgur.com/nrsoLAH.png" width="800px">
</p>

## Installation

- Download & copy purify.css to your desired directory.

- Include the theme in your html with:

```html
<link rel="stylesheet" href="purify.css">
```

- Make sure you follow [highlightjs instructions](https://highlightjs.org/) too

## References

[highlightjs](https://highlightjs.org/) Syntax highlighting for the Web

## Lisence
MIT © [Kyoz](mailto:banminkyoz@gmail.com)
