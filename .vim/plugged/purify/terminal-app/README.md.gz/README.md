# Terminal.app (OSX)
> Purify theme for OSX default terminal

<p align="center">
  <img src="https://i.imgur.com/Va0NaV7.png" width="800px">
</p>

## Installation

Download and import `purify.terminal` to your OSX terminal

## References

If you are using zsh, please take a look at [purify/zsh](https://github.com/kyoz/purify/tree/master/zsh) to get zsh config for purify.

## Lisence
MIT © [Kyoz](mailto:banminkyoz@gmail.com)
