# rofi
> Purify theme for rofi

## Installation

If you haven't config rofi yet, just download [purify theme file](./purify.rasi) and place the content of it in `~/.config/rofi/config.rasi`

If you already have your config file, just download [purify theme file](./purify.rasi) and place it in `~/.config/rofi/themes/purify.rasi`
Then and this line to your config:
```rasi
*{
	...
	theme: "./themes/purify";
	...
}
```

## Lisence
MIT © [Kyoz](mailto:banminkyoz@gmail.com)
